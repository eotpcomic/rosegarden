<?php

/**
 * Deprecated, functions moved to wc-functions.php, delete file in v6.
 *
 * This empty file is needed to not crash existing bootcommerce-child installations 
 * because they have require get_template_directory() . '/woocommerce/woocommerce-functions.php';
 * in their functions.php.
 */
